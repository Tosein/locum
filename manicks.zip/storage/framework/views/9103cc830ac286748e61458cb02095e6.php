<div class="col-lg-3 col-md-12">
  <div class="card">
      <ul class="list-group list-group-flush">
          <li class="list-group-item <?php echo e(Request::is('dentist/dashboard')? 'active' : ''); ?>">
              <a href="<?php echo e(route('dentist_dashboard')); ?>"
                  >Dashboard</a
              >
          </li>
          <li class="list-group-item <?php echo e(Request::is('dentist/edit_profile')? 'active' : ''); ?>">
            <a href="<?php echo e(Route('dentist_edit_profile')); ?>"
                >Edit Profile</a
            >
        </li>
          <li class="list-group-item">
              <a href="candidate-applied-jobs.html"
                  >Applied Jobs</a
              >
          </li>
          <li class="list-group-item">
              <a href="candidate-bookmarked-jobs.html"
                  >Bookings</a
              >
          </li>
          <li class="list-group-item">
              <a href="candidate-education.html"
                  >Education</a
              >
          </li>
          <li class="list-group-item">
              <a href="candidate-skill.html">Skills</a>
          </li>
          <li class="list-group-item">
              <a href="candidate-experience.html"
                  >Work Experience</a
              >
          </li>
          <li class="list-group-item">
              <a href="candidate-award.html">Certificates</a>
          </li>
          <li class="list-group-item">
            <a href="candidate-award.html">Licenses</a>
        </li>
         
          <li class="list-group-item">
              <a href="candidate-resume.html"
                  >Documents Upload</a
              >
          </li>
          <li class="list-group-item">
              <a href="<?php echo e(route('dentist_logout')); ?>">Logout</a>
          </li>
      </ul>
  </div>
</div><?php /**PATH C:\wamp64\www\manicks\resources\views/dentist/sidebar.blade.php ENDPATH**/ ?>