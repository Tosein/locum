<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AdminHomeController extends Controller
{
    public function home()
    {
        return view('admin.home');
    }
    public function login()
    {
        return view('admin.login');
    }
    public function admin_login_submit(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];

       if(Auth::guard('admin')->attempt($credentials)){
            return redirect()->route('admin_home');
       }else{
        return redirect()->route('admin_login')->with('error', 'wrong details!');
       }
    }
    public function logout()
    {
        Auth::guard('admin')->logout();
        return redirect()->route('admin_login');
    }
    public function forget_password()
    {
        return view('admin.forget_password');
    }
}