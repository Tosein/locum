<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Controller;
use App\Models\Company;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SignupController extends Controller
{
    public function index()
    {
        return view('front.signup');
    }

    public function company_signup_submit(Request $request)
    {
        $request->validate([
            'company_name' => 'required',
            'contact_name' => 'required',
            'username' => 'required|unique:companies',
            'email' => 'required|email|unique:companies',
            'password' => 'required',
            'retype_password' => 'required|same:password'
        ]);

        $token = hash('sha256',time());

        $company_signup = new Company();
        $company_signup->company_name = $request->company_name;
        $company_signup->contact_name = $request->contact_name;
        $company_signup->username = $request->username;
        $company_signup->email = $request->email;
        
        $company_signup->password = Hash::make($request->password);
        $company_signup->token = $token;
        $company_signup->save();


        return redirect()->route('home_login')->with(`success`, 'A message is sent to your email address');
    }
}

