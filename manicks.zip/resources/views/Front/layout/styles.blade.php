<link rel="stylesheet" href="{{ asset('dist-front/css/bootstrap.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/bootstrap-datepicker.min.css') }}" />
        <!--<link rel="stylesheet" href="css/jquery-ui.css" />-->
        <link rel="stylesheet" href="{{ asset('dist-front/css/animate.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/magnific-popup.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/owl.carousel.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/select2.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/select2-bootstrap.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/all.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/meanmenu.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/spacing.css') }}" />
        <link rel="stylesheet" href="{{ asset('dist-front/css/style.css') }}" />